#include"LevelStrategy.h"
#include<iostream>
using namespace std;
P1LStrategy::P1LStrategy(){
    level=1;
}
int P1LStrategy::getlevel(){
    return level;
}
P2LStrategy::P2LStrategy(){
    level=2;
}
int P2LStrategy::getlevel(){
    return level;
}
P3LStrategy::P3LStrategy(){
    level=3;
}
int P3LStrategy::getlevel(){
    return level;
}